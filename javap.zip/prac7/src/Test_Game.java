public class Test_Game {
    public static void main(String[] args){
        Game game = new Game();
    }
}
