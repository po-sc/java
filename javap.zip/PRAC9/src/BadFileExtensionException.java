public class BadFileExtensionException extends RuntimeException {
    public BadFileExtensionException(String message, Throwable cause) {
        super(message, cause);
    }
}
