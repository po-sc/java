public class BadINNException extends Exception {
    public BadINNException(String message) {
        super(message);
    }
}