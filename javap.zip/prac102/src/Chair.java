public interface Chair {
    void sit();
}
