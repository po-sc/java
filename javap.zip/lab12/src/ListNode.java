
public class ListNode {
    public ListNode next;
    public MenuItem value;

    public ListNode(MenuItem value) {
        this.value = value;
    }
}
