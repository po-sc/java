
public interface Alcoholable {
    boolean isAlcoholicDrink();
    double getAlcoholVol();
}
